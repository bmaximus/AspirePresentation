var builder = DistributedApplication.CreateBuilder(args);

var apiService = builder.AddProject<Projects.AspirePresentation_ApiService>("apiservice")
    .WithHttpHealthCheck("/health");




builder.AddProject<Projects.AspirePresentation_Web>("webfrontend")
    .WithExternalHttpEndpoints()
    .WithHttpHealthCheck("/health")
    .WithReference(apiService)
    .WaitFor(apiService);

builder.Build().Run();
